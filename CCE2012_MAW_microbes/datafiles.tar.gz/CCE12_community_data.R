### Load required libraries
library(phyloseq)
library(ggplot2)
library(vegan) ## for ordination
library(MASS) ## for certain NMDS related functions. possibly not needed
library(DESeq2)
library(grid) ## to load the arrows function for drawing arrows on plots
library(reshape2)

### Check package versions
packageVersion("phyloseq")
packageVersion("ggplot2")
packageVersion("DESeq2")

### Import the dataset and combine individual sample files

setwd("/home/shane/Documents/projects/current_projects/MiSeq_CCE_2012/OTU_processing/01.05.16_analysis/downstream_analysis")

DNA07 <- subset(as.data.frame(read.table("DNA07_otutab.txt", sep="\t", header=TRUE)), select = -taxonomy)
DNA08 <- subset(as.data.frame(read.table("DNA08_otutab.txt", sep="\t", header=TRUE)), select = -taxonomy)
DNA09 <- subset(as.data.frame(read.table("DNA09_otutab.txt", sep="\t", header=TRUE)), select = -taxonomy)
DNA10 <- subset(as.data.frame(read.table("DNA10_otutab.txt", sep="\t", header=TRUE)), select = -taxonomy)
DNA11 <- subset(as.data.frame(read.table("DNA11_otutab.txt", sep="\t", header=TRUE)), select = -taxonomy)
DNA12 <- subset(as.data.frame(read.table("DNA12_otutab.txt", sep="\t", header=TRUE)), select = -taxonomy)


samples.list = list(DNA07, DNA08, DNA09, DNA10, DNA11, DNA12)
OTU.tab = Reduce(function(...) merge(..., all=T), samples.list)
OTU.tab[is.na(OTU.tab)] <- 0
write.table(OTU.tab, file="allsamples_otu_table", quote = FALSE, row.names = FALSE, sep = "\t")
rownames(OTU.tab) <- OTU.tab[,1]
OTU.tab <- subset(OTU.tab, select = -OTU_ID)

OTU.tab <- as.matrix(read.table("allsamples_otu_table", row.names=1, sep="\t", header=TRUE))
taxmat <- as.matrix(read.table("rdp_tax_table", row.names=1, sep="\t", header=TRUE))
metamat <- as.data.frame(read.table("allsamples.metadata", row.names=1, sep="\t", header=TRUE))

### Generate phyloseq object
OTU = otu_table(OTU.tab, taxa_are_rows = TRUE)
TAX = tax_table(taxmat)
SAMPDAT = sample_data(metamat)
cce12 = phyloseq(OTU, TAX, SAMPDAT)

##Generate OTU sums across all samples and sort
OTUsums = data.frame(nreads = sort(taxa_sums(cce12), TRUE), sorted = 1:ntaxa(cce12))

#Now calculate the number of reads in each sample and make a table
samplesums = data.frame(read.count = sort(sample_sums(cce12), TRUE))

#plot rank abundance
ggplot(OTUsums, aes(x = sorted, y = nreads)) + geom_line(stat = "identity", size = 1) + theme_bw() +
  scale_y_log10() + labs(x = "OTU rank abundance", y = "Total number of reads")


### Preprocessing data

## use the subset taxa function to select only the Domain "Bacteria" while excluding "Cyanobacteria/chloroplast." cce12_st is a new phyloseq object
cce12_st <- subset_taxa(cce12, Phylum!="Cyanobacteria/Chloroplast")
cce12_st <- subset_taxa(cce12_st, Domain=="Bacteria")

#transform to relative abundance
cce12st.rel.abun <- transform_sample_counts(cce12_st, function(x) x / sum(x))
cce12st.rel.abun

#remove OTUs that have a mean percentage abundance of less than 0.005%.
cce12st.rel.abun.filter <- filter_taxa(cce12st.rel.abun, function(x) mean(x) > 5e-5, TRUE)
cce12st.rel.abun.filter

## collect OTUs from cce12.rel.abun.filter and use them to filter the raw OTUs from cce12
cce12.raw.filt <- prune_taxa(taxa_names(cce12st.rel.abun.filter), cce12)

#Remove taxa not seen more than 3 times in at least 20% of the samples. 
# This protects against OTUs with small mean & trivially large covariance
cce12.raw.filt.2 <- filter_taxa(cce12.raw.filt, function(x) sum(x > 3) > (0.2*length(x)), TRUE)

#Generate OTU sums across all samples in the new filtered set and sort
OTUsums1 <- data.frame(nreads = sort(taxa_sums(cce12.raw.filt.2), TRUE), sorted = 1:ntaxa(cce12.raw.filt.2))

## Plot new rank abundace curve based on reduced OTU set
ggplot(OTUsums1, aes(x = sorted, y = nreads)) + geom_line(stat = "identity", size = 1) + theme_bw() +
  scale_y_log10() + labs(x = "OTU rank abundance", y = "Total number of reads")

## again make a summary table of read counts for each library
samplesums_postfilter <- cbind(samplesums, data.frame(read.count.postfilter = sort(sample_sums(cce12.raw.filt), TRUE)), data.frame(read.count.postfilter.2 = sort(sample_sums(cce12.raw.filt.2), TRUE)))
samplesums_postfilter

#standardize abundances to the median sequencing depth of each sample
total.median <- median(sample_sums(cce12.raw.filt.2))
stdize.fun <- function(x, t=total.median) round(t * (x / sum(x)))

cce12norm = transform_sample_counts(cce12.raw.filt.2, stdize.fun)

###### Richness/alpha diversity of data partitioned by Fe_Treatment ######

## get numerical values for richness estimates and write output as a table
richness <- estimate_richness(cce12_st)
write.table(richness, file = "sample_richness_estimates.tsv", sep = "\t", row.names = T)

## plot richness of samples
p = plot_richness(cce12_st, x = "Fe_Treatment", color = "Sample_ID")
p + geom_point(data = p$data, aes(x = Fe_Treatment, y = value, color = Sample_ID), size = 4)

##only richness plots of Chao1 and "observed" diversity so we'll just select those
psub = plot_richness(cce12_st, x = "Fe_Treatment", color = "Sample_ID", measures = c("Observed", "Chao1")) + theme_bw()
psub + geom_point(data = psub$data, aes(x = Fe_Treatment, y = value, color = Sample_ID), size = 5)

### Bar plots
topOTUs = names(sort(taxa_sums(cce12norm), TRUE)[1:20])
cce12norm20 = prune_taxa(topOTUs, cce12norm)
plot_bar(cce12norm20, "Sample_ID", fill = "Family", facet_grid = ~OTU) + theme_bw()

plot_bar(cce12norm20, "Sample_ID", fill = "Class", facet_grid = ~Family) + theme_bw()


# combine OTUs at the taxonomic rank of Class. Results in 25 OTUs
glommed <- tax_glom(cce12norm, taxrank="Class")

# create variable OTUS_remove that contains the names of the 19 least
# abundant OTUs in the glommed dataset
OTUS_remove <- names(sort(taxa_sums(glommed), FALSE)[1:20])

# remove the 19 least abundant OTUs from the glommed dataset
glommed.red <- merge_taxa(glommed, OTUS_remove, 1)

# when this makes the bar plot it puts the components not in the same order for each sample
# do not know how to fix other than doing it the old fashioned way with ggplot
p <- plot_bar(glommed.red, "Sample_ID", fill = "Class")
p + geom_bar(aes(fill="Class", position="stack"))

# set up data frames produced from the tax_table and otu_tables from the glommed.red dataset
OTUs.class <- data.frame(otu_table(glommed.red))
tax.class <- data.frame(tax_table(glommed.red))

# merge data frames into one
merged.class.plot <- merge(OTUs.class, tax.class, by="row.names", all=TRUE)

# get rid of unecessary columns
merged.class.plot.red <- subset(merged.class.plot, select=-c(Row.names, Domain, Phylum, Order, Family, Genus))

# put df into long format and select id.vars as "Class"
merged.class.plot.red.m <- melt(merged.class.plot.red, id.vars="Class")

# make the bar plot
ggplot(merged.class.plot.red.m, aes(variable, value, fill=Class)) + geom_bar(stat="identity") + theme_bw()

### Detecting differential abundance of particular OTUs between Fe Treatments

#Import data with phyloseq, convert to DESeq2's DESeqDataSet class

FeTreat.dds = phyloseq_to_deseq2(cce12.raw.filt.2, ~ Fe_Treatment)

#Calculate geometric means prior to estimate size factors
gm_mean = function(x, na.rm=TRUE){
  exp(sum(log(x[x > 0]), na.rm=na.rm) / length(x))
}

geoMeans = apply(counts(FeTreat.dds), 1, gm_mean)
FeTreat.dds = estimateSizeFactors(FeTreat.dds, geoMeans = geoMeans)

##Running DESeq2 on non transformed data
FeTreat.dds = DESeq(FeTreat.dds, fitType="local")
res = results(FeTreat.dds)
res = res[order(res$padj, na.last=NA), ]
alpha = 0.05
sigtab = res[(res$padj < alpha), ]
sigtab = cbind(as(sigtab, "data.frame"), as(tax_table(cce12)[rownames(sigtab), ], "matrix"))
write.table(sigtab, file = "diff_abun_OTU.tsv", sep = "\t", row.names = T)
sigtab_red = subset(sigtab, select = -c(Domain, Phylum, Order, Family))
knitr::kable(sigtab_red)

### Ordination of data using phyloseq, vegan, ggplot and some other stuff...

#define a function veganotu for extracting an OTU table from a phyloseq object and coercing it into a form vegan likes
veganotu <- function(physeq) {
  OTU <- otu_table(physeq)
  if (taxa_are_rows(OTU)) {
    OTU <- t(OTU)
  }
  return(as(OTU, "matrix"))
}

##Convert physeq metadata into vanilla R data frames
keepvariables = which(sapply(sample_data(cce12.raw.filt.2), is.numeric))
physeqsd = data.frame(sample_data(cce12.raw.filt.2))[keepvariables]
physeqsd = subset(physeqsd, select = -Fe_level)
treatment = data.frame(sample_data(cce12.raw.filt.2))["Fe_Treatment"]

##Using the normalized OTU matrix in the metaMDS function
vegOTU <- vegdist(veganotu(cce12norm)) #creates a bray-curtis dissimilarity matrix
set.seed(4019)
vare.mds <- metaMDS(veganotu(cce12norm), trace = TRUE, plot = FALSE, autotransform = TRUE, noshare = FALSE, wascores = FALSE, trymax = 1000)


#Use the score function to load sample sites into vectors. 
#We also use plot_ordination function with the justDF option =TRUE in order to load the specific coordinates of just the OTUs.
scrs.site <- as.data.frame(scores(vare.mds, display = "sites"))
scrs.site <- cbind(scrs.site, treatment = treatment)
scrs.spp <- plot_ordination(cce12norm, vare.mds, type = "species", justDF = T) # To get species coordinates


#Now we use the envfit function to fit vectors to our continuous environmental data
set.seed(152)
ef <- envfit(vare.mds, physeqsd, permu = 999)
ef

##Use the score function again, but this time to load direction of environmental vectors. 
##Environmental vectors here are weighted by R<sup>2</sup> value
scrs.vct <- as.data.frame(scores(ef, display = "vectors"))

# ef is a list of lists. to get pvals you need the pvals list from the vectors list
vct.pvals <- ef[['vectors']]['pvals'] 

# combine the two
scrs.vct <- cbind(scrs.vct, vct.pvals) 

# select only rows with a P value < 0.1
scrs.vct <- scrs.vct[scrs.vct$pvals < 0.21,  ]  

#And finally, create the plot using ggplot

p <- ggplot(scrs.site, aes(x = NMDS1, y = NMDS2))
p + geom_point(data = scrs.site, aes(shape = Fe_Treatment), size = 6) + 
  coord_fixed() + ## need aspect ratio of 1!
  geom_segment(data = scrs.vct, aes(x = 0, xend = NMDS1/5, y = 0, yend = NMDS2/5), arrow = arrow(length = unit(0.25, "cm")), colour = "black") +
  geom_text(data = scrs.vct, aes(x = NMDS1/4.8, y = NMDS2/4.8, label = rownames(scrs.vct)), size = 3) +
  geom_point(data = scrs.spp, mapping = aes(x = NMDS1, y = NMDS2, color = Class), size = 3) + theme_bw()

write.table(scrs.site, file = "site_scores.tsv", sep = "\t", row.names = T)
write.table(scrs.spp, file = "spp_scores.tsv", sep = "\t", row.names = T)
write.table(scrs.vct, file = "envfit_scores.tsv", sep = "\t", row.names = T)

